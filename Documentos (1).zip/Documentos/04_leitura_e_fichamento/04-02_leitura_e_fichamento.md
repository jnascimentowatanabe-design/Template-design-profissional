# Etapa 4 Leitura e fichamento

## Solicitação

Preencha uma cópia deste template para cada artigo selecionado.

Obrigatoriedade de três artigos com no máximo 5 anos, ou seja, de publicação entre 2021 a 2026.

## Identificação do artigo

* Referência completa: `Inteligência artificial, data centers e colonialismo digital: Impactos socioambientais e geopolíticos a partir do Sul Global`
* DOI ou URL: `https://www.proquest.com/openview/a1794ee6e51ff235d2d8a403f3105f4f/1?pq-origsite=gscholar&cbl=5008010`
* Base de origem: `Portal Proquest`
* Leitor responsável: `Júlio Nascimento Watanabe`
* Data da leitura: `01/10/2026`

## Fichamento

### Problema investigado

`Uso dos recursos naturais de forma desmoderada para o funcionamento dos data centers, a ameaça da soberania digital através do colonialismo digital, e impactos socioambientais e geopolíticos dos data centers`

### Objetivo do estudo

`analisar os impactos socioambientais e geopolíticos causados pela infraestrutura dos data centers`

### Método utilizado

`Uma metodologia de cunho analítico baseado em fatos históricos e estruturado fundamentalmente em pesquisas e dados globais.` 

### Contexto, amostra ou dados

`Na conjuntura da crise climática e das demandas nacionais pelo estabelecimento da soberania
digital, o presente artigo discute os impactos socioambientais e geopolíticos relacionados à expansão de
data centers em territórios do Sul Global, movida sobretudo pelo aumento da demanda por serviços de
Inteligência Artificial.`

### Principais resultados

`A evidencia que ao contrário do "soculucionismos tecnologico", como abordado no artigo, existe múltiplas provas contra a imaterialidade tecnológico, mostrando a necessidade do uso de recursos naturais para que funcione o poder computacional, gerando impactos ambientais. Ademais o estudo destaca a assimetria do Norte Global que transfere a instalação de data centers poluentes, que exigem o uso de recursos naturais, para o Sul Global.`

### Limitações apresentadas

`As limitações metodológicas e acadêmicas do estudo decorrem da opacidade corporativa das grandes empresas de tecnologia, que tratam o consumo real de recursos como segredo comercial. Além disso, a pesquisa aponta a escassez de estudos acadêmicos integrados sobre a geopolítica do Sul Global e a consequente dependência de relatórios voluntários para estimar o passivo socioambiental. `

### Contribuição para o nosso artigo

`Esse artigo contribui muito para mostrar o quanto os Data Centers podem impactar diretamente nos locais onde ele é construindo gerando disputa por recursos, O posicionamento incoerente empresas de questionamento ao Estado soberano ao impor as tecnologias que devem ser usada , assim como também apresentou o conceito de colonialismo digital e soberania digital`

### Comentário crítico

`É um artigo com bastante embasamento em casos passados e valores de consumo já mensurados, mostrando a realidade simples com acontecimentos e pesquisas. Contudo, ao ponto de vista do leitor não demonstra uma solução efetiva uma vez que o modelo político já está enraizado, demonstrando desafios com complexidade muito altas para aplicar a solução porposta pelo artigo.`


## Checklist

* \[x] O artigo foi lido além do resumo.
* \[x] O método e os resultados foram identificados.
* \[x] As limitações foram registradas.
* \[x] A conexão com o tema foi explicada.
* \[x] Toda citação literal contém página.

