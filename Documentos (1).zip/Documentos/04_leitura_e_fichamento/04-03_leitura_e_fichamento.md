# Etapa 4 Leitura e fichamento

## Solicitação

Preencha uma cópia deste template para cada artigo selecionado.

Obrigatoriedade de três artigos com no máximo 5 anos, ou seja, de publicação entre 2021 a 2026.

## Identificação do artigo

* Referência completa: Data Centers no Ceará: as fronteiras entre a revolução tecnológica e o 'Risco Ecocídio'
* DOI ou URL: https://periodicos.apps.uern.br/index.php/jcd/article/view/7630
* Base de origem: Portal de Periódicos da UERN
* Leitor responsável: Felipe Oliveira Nascimento
* Data da leitura: 01/10/2026

## Fichamento

### Problema investigado

Possível destruição ambiental e a falta de leis para amparar o meio ambiente

### Objetivo do estudo

Analisar  os riscos  e limites  jurídicos  de empreendimento desse tipo para com as questões ambientais, especialmente pensando no conceito de ecocídio

### Método utilizado

Uma metodologia  interdisciplinar,  combinando  elementos  do  Direito  Internacional  Ambiental, da governança ESG e de estudos técnicos sobre consumo energético e hídrico em data centers, além dos dados divulgados e disponíveis sobre a capacidade do empreendimento em foco. 

### Contexto, amostra ou dados

Nas  últimas  duas  décadas,  o  número  de  data  centers10em  operação  cresceu exponencialmente, acompanhando a demanda por serviços em nuvem, redes sociais, streaming e, mais recentemente,  inteligência  artificial.  Segundo a International  Energy  Agency(IEA,  2024),  os  data centers já respondem por cerca de 1,5% do consumo total de eletricidade mundial, podendo dobrar até 2030 caso as tendências atuais se mantenham. Além disso, sua pegada de carbono é comparável ade países,  bem  como  o  uso  abundante  de  água,  especialmente  para  refrigeração,  equiparando-se  ao consumo de cidades de grande porte.

### Principais resultados

O resfriamento dos servidores exige sistemas intensivos, que competem com o abastecimento humano e o uso agropecuário. Estudos recentes indicam que data centers de grande porte podem consumir 20milhões de litros de água por dia, equivalente ao consumo de uma cidade de 50 mil pessoas. A escassez hídrica, portanto, não é apenas um risco técnico, mas um problema de justiça ambiental com impactos na vida cotidiana. Há o impacto territorial. A instalação de um data center requer infraestrutura  de  alta  tensão,  cabos  submarinos,  subestações,  estradas  e  grandes  áreas impermeabilizadas, por vezes construída em regiões de comunidades indígenas.

### Limitações apresentadas

É inegável que a chegada de empresas multinacionais de tecnologia no Ceará tende a ampliar a visibilidade do Estado, fortalecendo seu papel estratégico em cadeias globais de informação e, por consequência, atraindo novos negócios de infraestrutura digital e inovação, incluindo serviços de computação em nuvem, segurança cibernética e armazenamento. Projetos desse porte operam com empregos qualificados em todas as fases:da construção, operação, manutenção de servidores, à refrigeração e segurança da informação.  Para  um Estado  em  desenvolvimento,  com  renda  média  inferior  à  brasileira,  isso  se traduziria em oportunidades econômicas diretas e indiretas.Também,  a dinamização  econômica estimula o  surgimento  de  cadeias  produtivas associadas: expansão da demanda por energia renovável(a própria Casa dos Ventos atua neste ramo), serviços de engenharia, construção civil, infraestrutura de telecomunicações,além destartups focadas em análise de dados, IA e computação de alto desempenho.

### Contribuição para o nosso artigo

Esse artigo contribui muito para mostrar o quanto os Data Centers podem impactar diretamente nos locais onde ele é construindo gerando disputa por recursos, desertifcação transformando um estado já frágil em um local árido e semiárido, assim como também apresentou o conceito de Ecocídio

### Comentário crítico

É um artigo com bastante embasamento em casos passados e valores de consumo já mensurados, mostrando a realidade simples com números e comparações de como esses número é absurdo ao comparar um data center e uma cidade de 2,2 milhões de pessoas


## Checklist

* \[x] O artigo foi lido além do resumo.
* \[x] O método e os resultados foram identificados.
* \[x] As limitações foram registradas.
* \[x] A conexão com o tema foi explicada.
* \[x] Toda citação literal contém página.