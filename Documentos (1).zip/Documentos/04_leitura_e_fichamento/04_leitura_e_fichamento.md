# Etapa 4 Leitura e fichamento

## Solicitação

Preencha uma cópia deste template para cada artigo selecionado.

Obrigatoriedade de três artigos com no máximo 5 anos, ou seja, de publicação entre 2021 a 2026.

## Identificação do artigo

- Referência completa: `Regulação de data centers no Brasil: entre o direito ao desenvolvimento e a proteção ambiental`
- DOI ou URL: `https://doi.org/10.62530/e026023`
- Base de origem: `Revista Brasileira de Direito Constitucional - RBDC, Vol. 26`
- Leitor responsável: `Pedro Henrique Mello Rodrigues`
- Data da leitura: `\[28/09/2026 - 02/10/2026`

## Fichamento

### Problema investigado

`Fragilidade do Brasil legislativamente e ambientalmente para implementação de data centers.`

### Objetivo do estudo

`Destacar âmbitos e critérios que devem ser alvo de atenção e obter importância e relevância primordial, para que a hospedagem de data centers no Brasil ocorra de forma benéfica, estável, e segura.`

### Método utilizado

`Procuramos artigos científicos com dados e estudo, além de ser considerado na faixa de tempo solicitada, para não ter caso de utilizarmos informações desatualizadas.`

### Contexto, amostra ou dados

`Segundo relatórios mais recentes, data centers devem receber US$ 3 trilhões em investimentos mundialmente. No contexto da América Latina, o Brasil busca se posicionar como um destino atrativo para a instalação de data centers (Ministério das Comunicações, 2026).`

### Principais resultados

`Afirma-se lacunas regulatórias em vista do uso de data centers no Brasil, que não asseguram a integridade da natureza ao redor, pelo contrário expondo as áreas habitadas em disputa pelos recursos naturais. `

### Limitações apresentadas

`88% da energia que o Brasil produz é de fontes renováveis (hidreelétricas, solar e eólica), porém não são recursos dispostos integralmente, regiões passam por períodos intermitentes da disposição dessas fontes, inflacionando o custo da utilização dessas tecnologia, causando escassez desses recursos para usuários comuns ou se tirando o acesso dessas pessoas sobre esses serviços.`

### Contribuição para o nosso artigo

`Ao decorrer da leitura do artigo, essas e outras questões foram formuladas e alarmadas, o artigo diz sobre projetos de lei que prometem um preparo ambiental mais adaptativo.`

### Comentário crítico

`O Brasil se encontra com um método de implementação parecido com o estadunidense, de acordo com o trecho: "Verificou-se que o Brasil reúne condições atrativas para investimentos, mas apresenta fragilidade regulatória. A análise comparada evidencia dois modelos predominantes: o europeu, baseado em transparência e eficiência energética, e o norte-americano, orientado por incentivos econômicos e menor densidade regulatória, com externalização de custos ambientais...", e se continuar desse jeito, mais uma tentativa frustrada de melhorar o país entrará na longa fila de manutenção de regulamento, causando dores sociais.`

### Citação literal opcional

> `\[trecho exato]`

Página: `\[número]`

## Checklist

- \[X] O artigo foi lido além do resumo.
- \[X] O método e os resultados foram identificados.
- \[X] As limitações foram registradas.
- \[X] A conexão com o tema foi explicada.
- \[X] Toda citação literal contém página.
