# Etapa 6 Redação do artigo

## Solicitação

Escreva a primeira versão completa do artigo seguindo a estrutura abaixo. 500 a 1000 palavras.

# Título

`A falta de preparo do Brasil para receber os data centers e os impactos socioambientais causados por essas tecnologias`

## Palavras-chave

`Data centers; Meio ambiente; Ecocídio`

## Introdução

`A nova tecnologia popular entre o povo é a IA (inteligência artificial), sendo que sua demanda tem crescido exponencialmente devido a utilização dessa ferramenta, estando o Brasil entre a segunda e terceira posição do país que mais usa a IA no dia a dia ou no trabalho, de acordo com a Cisco System, uma das maiores empresas de tecnologia. Entretanto, a ampla utilização dessa tecnologia está em função ao crescente funcionamento e construções de infraestruturas responsibilizadas pelo poder computacional, os data centers. Tais maquinários, assim como outros corroboram para o aumento da crise climática e socioambiental do Brasil, tornando o país alvo de companias transnacionais, uma vez que a nação é uma das mais utilizadoras de seu produto e grandes quantidades de recursos naturais e infraestrutura.`

## Metodologia

`Trata-se de uma revisão narrativa da literatura, com abordagem crítica e qualitativa. A busca foi realizada nas bases Google Acadêmico, Revista Brasileira de Direito Constitucional, Portal Proquest e Portal de Periódicos da UERN, com os descritores "data centers", "impactos socioambientais", "meio ambiente", "Brasil" e "inteligência artificial". Foram incluídos artigos ciêntificos nos últimos cinco anos, em português, que tratassem de impactos socioambientais de data centers. A triagem ocorreu em duas etapas, leitura de títulos e resumos e depois leitura completa, e a análise foi comparativa, agrupando os achados em três eixos temáticos.`

## Revisão da literatura

### `Fragilidade política e ambiental brasileira para hospedagem de data centers`

`A qualidade da água também importa, porque ela estará em contato com componentes delicados. Por isso, água salgada não serve e mesmo a água doce deve ser tratada. Muitos data centers suprem essa demanda por água, que varia conforme o tipo de sistema adotado (aberto ou fechado), por meio da rede municipal de fornecimento, levando-a ao limite e potencialmente privando a população local de água (BBC, 2025). É relevante destacar que há uma diferença significativa no consumo direto de água entre data centers de sistema aberto ou fechado. Data centers de sistema aberto (open loop) utilizam modelo de resfriamento em circuito aberto, no qual a água é captada do ambiente, muitas vezes do sistema municipal. A água passa pelo processo de resfriamento e depois é descartada de volta ao meio externo, normalmente em temperatura mais alta. Esse tipo de sistema tende a ser mais eficiente energeticamente, mas consome grandes volumes de água, representando um impacto ecológico maior nos corpos hídricos. Já os data centers de sistema fechado (closed loop), que são a grande maioria no Brasil na última década, operam com circuitos fechados de água, nos quais o líquido circula continuamente dentro da própria instalação, sem captação ou descarte constante no ambiente. A água é resfriada internamente. Apesar de reduzir drasticamente o consumo hídrico total, esse modelo consome mais energia do que o ciclo aberto, especialmente em climas quentes, porque os compressores dos “chillers” responsáveis por manter a água refrigerada precisam trabalhar mais. Isso ainda representa um impacto ambiental indireto significativo a partir da necessidade de suprir essa crescente demanda energética.`

### `Analisar  os riscos  e limites  jurídicos  de empreendimento desse tipo para com as questões ambientais, especialmente pensando no conceito de ecocídio`

`De acordo com o que foi apresentado, dados de data centers que já foram mensurados em trabalho e as estimativas feitas pelos estudiosos da área, fica evidente a necessidade de uma transparência, detalhamento e aprofundamento maior nos estudos de opções para refrigeração desse tipo de tecnologia, assim como leis para amparar as regiões próximas dos futuros data centers no Brasil, pois do modo como está deixa de ser um benefício tê-los em nosso território e se torna um perigo socioambiental, podendo desertificar toda uma região que já vem lutando contra isso a anos, uma região que é fragilizada hidricamente falando, mas está sendo vista como um local propício por conta da infraestrutura de cabos submarinos e possibilidade de uso de energia eólica, mas isso não deveria bastar para escolher uma região para esse tipo de construção.
Essas leis vão servir em grande parte para assegurar que não seja cometido ecocídio, que é qualquer destruição em larga escala do meio ambiente ou à sobre-exploração de recursos não-renováveis, que são preocupações reais quando se coloca em vista os dados coletados das estimativas de gastos de água desse data center que será construído no Ceará, 19.700 litros/dia incluindo uso sanitário, que equivaleria ao consumo médio de quase 47 residências em Caucaia, mas por conta da ausência de leis específicas para esse tipo de empreendimento foi autorizado utilizar um volume de 144 mil litros de água por dia, um consumo equivalente a 340 residências, por dia.`

### `Compreender os impactos socioambientais e geopolíticos causados pela infraestrutura dos data centers`

`De acodo com o os dados mostrados anteriormente, o Brasil possui sua geração energética voltada na produção renovável. Contudo, por mais que condições climáticas e naturais do Braisl sejam propícias para atrair transnacionais de data centers, o país não possui condições para sustentar essa tecnologia, uma vez que a nação sofre de diversas escassez. Isso é possível de analisar dados concretos onde em 2024, Vinhedo, cidade na rota de expansão do setor, adotou racionamento de água (FURTADO; CUNHA, 2024, p. 11), e a demanda dos data centers no eixo São Paulo-Campinas deve triplicar até 2030, enquanto a capacidade de distribuição de energia cresce apenas 20% (FURTADO; CUNHA, 2024, p. 7).
Ademais as condições limitadas do Brasil, há um questionamento sobre a soberania digital do país, sendo que as companias tecnologicas estabelecem recursos específicos dos seus data centers corroborando com os impactos ambientais, como o aumento da geração de gases efeito estufa (GEE), a utilização de água de forma excessiva e o uso indevido de minérios. As emissões da GEE da Google resgsitrou uma taxa de aumento de 48% devido aos data centers. Enquanto isso o consumo de água por esses maquinários pela Microsoft atingiu 7 milhões de m³.  
Com isso, é possível enxergar não só a problemática ambientalista, mas também geopolítica da nação, uma vez que o Brasil encontra em uma posição relativamente inferior nas suas decisões tecnopolíticas. Isso faz com que as empresas de TI, especialmente do exterior, compromentam a soberania digital ao instalar data centers no Brasil de acordo com as próprias regulamentações. Em Limeira (SP), um projeto foi barrado por contrariar a legislação sobre venda de terras a estrangeiros, mas o Plano Diretor foi alterado para permitir a obra (FURTADO; CUNHA, 2024, p. 12). `

### Síntese crítica

`Os estudos analisados convergem acerca dos impactos ambientais do Brasil na implementações dos data centers e desenvolvem pontos interessantes acerca do futuro, colocando cenários como a crise dos recusos hídricos e energéticos, ainda que o Brasil possui uma matriz limpa (FURTADO; CUNHA; 2024). Contudo, as Investigações dos artigos divergem ao abordar conceitos de Ecocído, exploração da dependência tecnologica do Brasil, questionando a soberania digital através do colonialismo digital, e temas que perscruta a legislação do Brasil no que tange aos data centers e o Brasil. Além disso, é aferido lacunas dentro dos estudos, prinicpalmente quando trata-se de dados mais precisos do consumo de água e energia dentro do Brasil.`

## Considerações finais

` Sendo assim, o Brasil possui um desafio, sendo a decisão da elaboração de regulamentações dos data centers no país, pois além de comprometer questões ecológicas da região, como a falta dos recursos energéticos e hidricos, também fragiliza a posição do país diante das outra nações, no que tange a soberania do país. Ademais, outras questões também são alcançadas como o ecocídio.
Portanto, considerando as premissas abordadas, se a corrida tecnologica entre as empresas prosseguir de forma irrestrita em relação as regulamentações nacionais, os impactos socioambientais futuros sobre o Brasil serão graves, considerando o aquecimento global e as escassez dos recursos hídricos. Ademais, não há uma garantia, mas a soberania do Brasil torna-se volúvel diante da região do Norte Global, podendo ser considerado pelos outros países uma nação subalternada.`

## Resumo

`Com a expansão da inteligência artificial, cresce a demanda por data centers, e o Brasil, por sua matriz renovável, tornou-se atrativo para empresas transnacionais. Este artigo analisa, por revisão da literatura em [bases de dados], a falta de preparo do país para essa infraestrutura e seus impactos socioambientais. Os estudos apontam escassez hídrica, limites na rede elétrica, regulação defasada e dependência de empresas estrangeiras. Conclui-se que o Brasil ainda não está preparado e precisa de regulamentação específica para o setor.`

## Referências

`FURTADO, Renato Guimarães; CUNHA, Simone Evangelista. Inteligência artificial, data centers e colonialismo digital: impactos socioambientais e geopolíticos a partir do Sul Global. Liinc em Revista, Rio de Janeiro, v. 20, n. 2, e7272, nov. 2024. DOI: 10.18617/liinc.v20i2.7272.

BROCHADO NETO, Djalma Alvarez. Data centers no Ceará: as fronteiras entre a revolução tecnológica e o "risco ecocídio". Revista Jurídicidade Constitucional e Democracia, Mossoró, v. 3, n. 5, p. 25-58, jun./dez. 2025.

NASSAR, Bruno Nazih Nehme; MORAES, Alexandre Rocha Almeida de. Regulação de data centers no Brasil: entre o direito ao desenvolvimento e a proteção ambiental. Revista Brasileira de Direito Constitucional, São Paulo, v. 26, jan./dez. 2026, e026023. DOI: 10.62530/e026023.
`

## Checklist

* \[X] A introdução termina com o objetivo.
* \[X] A metodologia descreve o processo realmente realizado.
* \[X] A revisão compara os artigos.
* \[X] A conclusão responde ao problema.
* \[X] O resumo representa o texto completo.

