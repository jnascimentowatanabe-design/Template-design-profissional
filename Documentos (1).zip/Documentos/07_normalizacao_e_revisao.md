# Etapa 7 Normalização e revisão final

## Solicitação

Revise o conteúdo, as citações, as referências e a formatação antes da entrega.

## Identificação

* Título do artigo: `[Regulação de data centers no Brasil: entre o direito ao desenvolvimento e a proteção ambiental, Inteligência artificial, data centers e colonialismo digital: Impactos socioambientais e geopolíticos a partir do Sul Global, as fronteiras entre a revolução tecnológica e o 'Risco Ecocídio]`
* Versão revisada: `1`
* Data: `05/10/2026`
* Responsável pela conferência final: `[Carlos Eduardo de Sant' Anna Filho]`

## Revisão científica

* [X] Tema, problema e objetivos estão alinhados.
* [X] As conclusões respondem ao problema.
* [X] Não existem afirmações sem fonte quando a fonte é necessária.
* [X] As limitações do trabalho foram reconhecidas.
* [X] Não foram incluídos resultados inexistentes.

## Citações e referências

* [X] Toda obra citada aparece nas referências.
* [X] Toda referência listada foi citada no texto.
* [X] Citações diretas contêm página.
* [X] Autores, títulos, anos, DOI e links foram conferidos.
* [X] O padrão exigido foi aplicado de forma consistente.

## Escrita

* [X] O texto possui sequência lógica.
* [X] Os parágrafos apresentam uma ideia principal.
* [X] Foram corrigidos ortografia e concordância.
* [X] Repetições e frases vagas foram eliminadas.
* [X] O texto diferencia descrição de análise crítica.

## Formatação

* [X] O template institucional foi respeitado.
* [X] Títulos e subtítulos estão padronizados.
* [X] Margens, fonte, espaçamento e paginação foram conferidos.

## Registro das correções

|Seção|Problema encontrado|Correção realizada|Responsável|
|-|-|-|-|
|`04_leitura_e_fichamento.md` - Método utilizado|O método colocado descrevia mais como o artigo foi procurado do que o método usado pelos autores do estudo.|Foi colocado o método usado pelos autores no artigo.|`[Carlos Eduardo de Sant' Anna Filho]`|
|`04_leitura_e_fichamento.md` - Comentário crítico|Havia uma citação direta sem indicação da página.|Foi acrescentada a indicação da página à citação.|`[Carlos Eduardo de Sant' Anna Filho]`|
|`04-02_leitura_e_fichamento.md` - Escrita|Havia erros de ortografia, concordância e algumas frases pouco claras.|Foram feitas correções de escrita sem alterar a ideia original do fichamento.|`[Carlos Eduardo de Sant' Anna Filho]`|
|`04-03_leitura_e_fichamento.md` - Limitações apresentadas|O conteúdo colocado nesse campo falava mais sobre benefícios econômicos do empreendimento do que sobre limitações do estudo.|O campo foi substituído pelas limitações apresentadas pelo próprio artigo.|`[Carlos Eduardo de Sant' Anna Filho]`|
|`04-03_leitura_e_fichamento.md` - Resultados e comentário crítico|As comparações com uma cidade de 50 mil pessoas e com 2,2 milhões de pessoas podiam parecer contraditórias.|Foi deixado claro que uma comparação se refere ao consumo de água e a outra ao consumo de energia.|`[Carlos Eduardo de Sant' Anna Filho]`|
|`05_matriz_de_sintese.md` - Convergências e comparações|Algumas ideias apareciam repetidas de forma muito semelhante nos três eixos.|As comparações foram ajustadas para mostrar melhor o que os artigos têm em comum e o que cada um acrescenta de diferente.|`[Carlos Eduardo de Sant' Anna Filho]`|
|`05_matriz_de_sintese.md` - Síntese crítica provisória|Tinha afirmações muito amplas que precisavam ficar mais ligadas às evidências apresentadas pelos artigos.|A síntese foi ajustada para relacionar melhor as conclusões aos dados e argumentos apresentados nas fontes.|`[Carlos Eduardo de Sant' Anna Filho]`|
|`05_matriz_de_sintese.md` - Escrita geral|Tinha muitos erros de ortografia.|Foram corrigidos os erros identificados.|`[Carlos Eduardo de Sant' Anna Filho]`|



