# Etapa 1 Tema e delimitação

## Solicitação

Defina um tema específico, relevante e viável para o artigo de revisão bibliográfica.

## Identificação

- Grupo: `[preencher]`
- Integrantes: `Júlio Nascimento Watanabe, Felipe Oliveira Nascimento, Pedro Henrique Mello Rodrigues, Carlos Eduardo de Santanna Filho`
- Data: `[22/09/2026]`

## Preenchimento

### Área geral

`Impacto social da tecnologia`

### Tema delimitado

`Impacto social e ambiental da infraestrutura e processamento maquinário dos Data Centers sobre comunidades circunvizinhas`

### Do tema amplo ao específico

- Tema amplo: `Impacto social da tecnologia`
- Objeto estudado: `Infraestrutura física e componentes de hardware empregados em data centers.`
- Contexto ou aplicação: `Investigação dos impactos decorrentes da instalação e operação de data centers sobre as populações residentes nas áreas circunvizinhas, considerando aspectos relacionados à infraestrutura computacional, à emissão de ruídos e às condições ambientais locais.`
- Aspecto que será analisado: ```Impactos potenciais sobre a saúde e o bem-estar das populações residentes no entorno dos data centers; | Poluição sonora decorrente da operação dos sistemas de infraestrutura, incluindo sistemas de refrigeração, ventilação e demais equipamentos eletromecânicos; | Caracterização básica do hardware utilizado em data centers de grande escala, com ênfase nos equipamentos computacionais e na infraestrutura necessária para seu funcionamento; | Relação entre a operação da infraestrutura física dos data centers e seus possíveis impactos socioambientais na comunidade local.```
- O que ficará fora do estudo: `O trabalho não abordará aspectos relacionados ao desenvolvimento, funcionamento ou gerenciamento de software utilizado nos data centers, concentrando-se nos componentes físicos da infraestrutura e em seus impactos sobre a população e o ambiente no entorno.`

### Justificativa

`Conforme o avanço tecnológico, houve uma expansão de grandes máquinas chamadas "Data Centers". Tais tecnologias, evocaram novos impactos socioambientais, sendo o dever humanitário aquilatar os danos provenientes do processamento infraestrutural durante o extenso périodo de funcionamento.`

### Viabilidade

- Há artigos científicos disponíveis? `Sim`
- O tema pode ser estudado no prazo? `Sim`
- O grupo possui acesso às fontes necessárias? `Sim`

## Produto da etapa

Tema delimitado e justificativa.

## Checklist

- [X] O tema é específico.
- [X] O tema é relevante.
- [X] O tema é viável.
- [X] O recorte está claro.
- [X] O tema foi validado pelo professor.

## Contribuições

| Integrante | Atividade realizada |
|---|---|
| `Júlio Nascimento Watanabe` | `Pesquisa de artigos científicos, elaboração do texto e engenharia do tema proposto` |
| `Felipe Olivera Nascimento` | `Pesquisa de artigos científicos, elaboração do texto e engenharia do tema proposto` |

