# Etapa 2 Problema de pesquisa

## Solicitação

Transforme o tema em uma pergunta clara, específica e respondível por meio da literatura científica.

## Tema aprovado

`Impacto social e ambiental da infraestrutura e processamento maquinário dos Data Centers sobre comunidades circunvizinhas`

## Pergunta de pesquisa

`Qual o impacto social e ambiental, que afetam as pessoas e o meio ambiente, causado pelas tecnologias de hardware dos Data Centers?`

## Verificação

- O que se deseja descobrir ou compreender? `Os impactos negativos gerados pelo uso dos Data Centers, em larga escala.`
- Qual é o objeto da pergunta? `Data Centers de grandes empresas que causam mudanças climáticas e altera a qualidade de vida`
- Qual é o contexto ou recorte? `Investigação dos impactos decorrentes da instalação e operação de data centers sobre as populações residentes nas áreas circunvizinhas, considerando aspectos relacionados à infraestrutura computacional, à emissão de ruídos e às condições ambientais locais.`
- A pergunta pode ser respondida por artigos científicos? `Sim, pois o material utilizado para estruturação desse artigo universitário, usa como fontes artigos científicos.`
- Por que essa pergunta é relevante? `Com o avanço da tecnologia, foram-se avançando também as estruturas, e uma dessas estruturas são os Data Centers, porém as grandes empresas apresentam discursos de "Greenwashing" para mascarar práticas que afetam questões ambientais e éticas, resultando em alterações extremas na bioesfera.`

## Produto da etapa

Pergunta de pesquisa aprovada.

## Checklist

- [X] Está escrita em forma de pergunta.
- [X] É clara e objetiva.
- [X] Está alinhada ao tema.
- [X] Pode ser respondida por revisão bibliográfica.
- [X] Não exige experimento que não será realizado.

## Contribuições

| Integrante | Atividade realizada |
|---|---|
| `Pedro Henrique Mello Rodrigues` | `Análise do tema proposto e inserção no modelo de problema de pesquisa` 
| `Carlos Eduardo de Santanna Filho` | `Análise do tema proposto e inserção no modelo de problema de pesquisa`
