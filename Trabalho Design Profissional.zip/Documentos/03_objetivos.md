# Etapa 3 Objetivo geral e objetivos específicos

## Solicitação

Defina o objetivo geral e os objetivos específicos do artigo.

## Problema de pesquisa

`Qual o impacto social e ambiental, que afetam as pessoas e o meio ambiente, causado pelas tecnologias de hardware dos Data Centers?`

## Objetivo geral

`Analisar os impactos sociais e ambientais causados pelos Data Centers nas esferas socioambientais`

## Objetivos específicos

1. `Identificar motivos para os impérios colonialistas de Data Centers`
2. `Mapear os Data Centers com maiores participações na degradação ecológicas`
3. `Analisar impactos negativos criados pelas grandes companhias que detém o monopólio dos Data Centers`
4. `Sintetizar possibilidades para amenização das consequências geradas pelo uso excessivo e incorreto dos Data Centers `

## Quadro de alinhamento

| Elemento | Texto |
|---|---|
| Problema | `A fomentação da disputa tecnológica de Data Centers e os efeitos socioambientais dessas tecnologias.` |
| Objetivo geral | `Analisar os impactos sociais e ambientais causados pelos Data Centers nas esferas socioambientais` |
| Resultado esperado | `Conscientização das possibilidades para amenização das consequências geradas pelo uso excessivo e incorreto dos Data Centers ` ` |

## Produto da etapa

Um objetivo geral e de três a quatro objetivos específicos.

## Checklist

- [X] Os objetivos começam com verbos no infinitivo.
- [X] O objetivo geral responde ao problema.
- [X] Os objetivos específicos detalham o objetivo geral.
- [X] Os objetivos são compatíveis com uma revisão bibliográfica.
